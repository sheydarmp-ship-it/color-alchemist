use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::TcpStream;

use crate::multiplayer::protocol::Packet;

pub struct Client {
    stream: TcpStream,
}

impl Client {
    pub async fn connect(addr: &str) -> Self {
        let stream = TcpStream::connect(addr)
            .await
            .expect("Cannot connect to server");


        Self { stream }
    }

    pub async fn send(
        &mut self,
        packet: Packet,
    ) {
        let json =
    serde_json::to_string(&packet).unwrap();

    let message = format!("{json}\n");

    self.stream
    .write_all(message.as_bytes())
    .await
    .unwrap();
    }
    pub async fn receive(
    &mut self,
) -> Packet {

    let mut reader =
        BufReader::new(&mut self.stream);

    let mut line =
        String::new();

    reader
        .read_line(&mut line)
        .await
        .unwrap();

    serde_json::from_str(&line).unwrap()
}
}