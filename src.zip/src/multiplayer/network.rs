use std::thread;

use tokio::runtime::Runtime;

use crate::multiplayer::client::Client;

pub struct NetworkManager {
    pub client: Option<Client>,
}

impl NetworkManager {
    pub fn new() -> Self {
        Self {
            client: None,
        }
    }

    pub fn connect(&mut self, addr: &str) {

        let address = addr.to_string();

        thread::spawn(move || {

            let runtime = Runtime::new().unwrap();

            runtime.block_on(async move {

                let _client =
                    Client::connect(&address).await;

                println!("Network Thread Connected!");

                loop {
                    tokio::time::sleep(
                        std::time::Duration::from_secs(1)
                    ).await;
                }

            });

        });

    }
}